@echo off
rem fatmax installer for Windows. Double-click this file.
rem It runs install.ps1 in the same folder (execution policy is bypassed for this run only).
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" %*
echo.
pause
