﻿# fatmax を Windows に入れる（ウォッチャー + hook + OTel）。
#
#   このファイルと fatmax.exe を同じフォルダに置いて、install.cmd をダブルクリック
#   （または PowerShell で: .\install.cmd -Hub http://<ハブの IP>:8787）
#   宛先を渡さなければ、ここで聞く（公開している一式は宛先を焼かない。LAN の IP は人ごとに違う）
#
# やること:
#   1. fatmax.exe を %USERPROFILE%\.fatmax\bin\ に置く（hook がここを見る）
#   2. ハブに届くか確かめる
#   3. ハブの宛先を保存する（fatmax.exe setup --hub …）
#   4. hook と OTel を入れる（ハブの setup.ps1。ユーザ全体の settings.json）
#   5. ウォッチャーを裏で起動する（ログは %USERPROFILE%\.fatmax\watch.log）
#
# **このファイルは UTF-8（BOM 付き）で配る。** Windows PowerShell 5.1 は BOM の無い .ps1 を
# ANSI（日本語版なら Shift_JIS）で読むので、日本語が化けて途中で止まる。
param(
  [string]$Hub = '',
  [switch]$NoStart
)
$ErrorActionPreference = 'Stop'

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$src = Join-Path $here 'fatmax.exe'
if (-not (Test-Path $src)) {
  throw "fatmax.exe が見つかりません: $src（このスクリプトと同じフォルダに置いてください）"
}
# 焼き込みの目印がそのまま残っている（原本を直に叩いた）ときも「渡されていない」と同じに扱う。
# 目印を文字列で書くと、焼くときの置換でここまで書き換わるので、2つに割って書く。
if ($Hub -eq ('@' + 'HUB@')) { $Hub = '' }
while (-not $Hub.Trim()) {
  $Hub = Read-Host 'ハブのアドレスを入れてください（例: 192.168.0.10:8787）'
}
$Hub = $Hub.Trim().TrimEnd('/')
if ($Hub -notmatch '^https?://') { $Hub = "http://$Hub" }

$dir = Join-Path $HOME '.fatmax'
$bin = Join-Path $dir 'bin'
$exe = Join-Path $bin 'fatmax.exe'
New-Item -ItemType Directory -Force -Path $bin | Out-Null

# 1. 置く。**動いている .exe は上書きできない**ので、ここに置いたウォッチャーだけ先に止める。
Get-Process fatmax -ErrorAction SilentlyContinue |
  Where-Object { $_.Path -eq $exe } |
  ForEach-Object { Write-Host "動いているウォッチャーを止めます (pid $($_.Id))"; Stop-Process -Id $_.Id -Force }
Start-Sleep -Milliseconds 500
Copy-Item $src $exe -Force
# ブラウザで落とした zip から出したものには「Web から来た」印が付いたまま写る。
# 付いていると SmartScreen / Smart App Control が止めるので外しておく（無ければ何もしない）。
try { Unblock-File $exe } catch { }
Write-Host "置きました: $exe"
& $exe --version

# 2. 届くか。**届かないまま入れると、記録が溜まるだけで誰も気付かない**ので、ここで止める。
try {
  Invoke-RestMethod "$Hub/healthz" -TimeoutSec 5 | Out-Null
  Write-Host "✓ ハブに届きます: $Hub" -ForegroundColor Green
} catch {
  Write-Host "✗ ハブに届きません: $Hub" -ForegroundColor Red
  Write-Host '  ハブの IP・ポート・ファイアウォールを確かめてください。宛先を変えるなら:'
  Write-Host "    .\install.cmd -Hub http://<ハブの IP>:8787"
  exit 1
}

# 3. 宛先を保存（%USERPROFILE%\.fatmax\hub の1行。ウォッチャーは送るたびに読み直す）
& $exe setup --hub $Hub

# 4. hook と OTel。**ハブが配っている setup.ps1 をそのまま使う**（決める場所を1つにする）。
#    最後に「irm …/hub/bin/windows」と案内が出るが、実行ファイルは 1. で置いてあるので不要。
& ([scriptblock]::Create((Invoke-RestMethod "$Hub/setup.ps1")))

# 5. ウォッチャー。**動かさないと記録はハブへ上がらない**（溜まるだけで消えはしない）。
if (-not $NoStart) {
  Start-Process -FilePath $exe -ArgumentList 'watch' -WindowStyle Hidden `
    -RedirectStandardOutput (Join-Path $dir 'watch.log') `
    -RedirectStandardError (Join-Path $dir 'watch.err.log')
  Start-Sleep -Seconds 3
  & $exe status
}

Write-Host ''
Write-Host '終わりました。**Claude Code を開き直してください**（OTel の設定は起動時にしか読まれません）。'
Write-Host 'ウォッチャーはサインアウト・再起動で止まります。そのときはもう一度:'
Write-Host "    Start-Process '$exe' -ArgumentList watch -WindowStyle Hidden"
Write-Host '画面に出る名前を変えるなら:'
Write-Host "    Set-Content `"$HOME\.claude\fatmax-host`" '開発機-Win'"
