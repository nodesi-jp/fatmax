﻿# fatmax を Windows に入れる（ウォッチャー + hook + OTel）。
#
#   このファイルと fatmax.exe を同じフォルダに置いて、install.cmd をダブルクリック
#   （または PowerShell で: .\install.cmd -Hub https://<ハブの IP>:8787 -Pin <指紋> -Token <トークン>）
#   渡さなければ、ここで聞く（公開している一式は宛先を焼かない。LAN の IP は人ごとに違う）。
#   指紋とトークンはハブの画面の「導入」に出ている（README の設計判断12）
#
# やること:
#   1. fatmax.exe を %USERPROFILE%\.fatmax\bin\ に置く（hook がここを見る）
#   2. ハブの宛先・指紋・トークンを保存し、届くか確かめる（fatmax.exe setup …）
#   3. hook と OTel を入れる（ハブの setup.ps1 を fatmax.exe fetch で取る。ユーザ全体の settings.json）
#
# **ハブから取るものは全部 fatmax.exe に取らせる。** PowerShell の irm は、ハブが自分で
# 作った証明書を指紋で照合できない（照合を切ると、偽のハブのものでも通る）。
#   5. ウォッチャーを別の窓で起動する（窓を閉じると止まる）
#
# **このファイルは UTF-8（BOM 付き）で配る。** Windows PowerShell 5.1 は BOM の無い .ps1 を
# ANSI（日本語版なら Shift_JIS）で読むので、日本語が化けて途中で止まる。
# **BOM は組むとき（dist/build-windows-kit.sh）に1つだけ付ける。この原本には付けない。**
# 原本にも付いていたせいで配ったものが BOM 2つになり、2つ目が本文の1文字として読まれて
# 1行目のコメントがコマンドに化け、`param(...)` が先頭の宣言でなくなって
# 「代入式が無効です」で止まった（0.1.167 の一式。組むほうでも2つにならないよう落としている）。
param(
  [string]$Hub = '',
  [string]$Pin = '',
  [string]$Token = '',
  # hook の1行の形。既定はハブの setup.ps1 が Git Bash を探して決める（Claude Code が hook を
  # Git Bash で動かし、無ければ PowerShell で動かすため）。見立てが違うときだけ bash / powershell を渡す
  [ValidateSet('auto','bash','powershell')][string]$Shell = 'auto',
  # hook とエージェント定義は Claude Code のプラグイン（fatmax@fatmax）に任せる（/fatmax:setup が付ける）
  [switch]$Plugin,
  [switch]$NoStart
)
$ErrorActionPreference = 'Stop'

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$src = Join-Path $here 'fatmax.exe'
if (-not (Test-Path $src)) {
  throw "fatmax.exe が見つかりません: $src（このスクリプトと同じフォルダに置いてください）"
}
# 焼き込みの目印がそのまま残っている（原本を直に叩いた）ときも「渡されていない」と同じに扱う。
# 目印を文字列で書くと、焼くときの置換でここまで書き換わるので、2つに割って書く。
if ($Hub -eq ('@' + 'HUB@')) { $Hub = '' }

# **前に入れた値を使い回す**（aws configure と同じ。[ ] の中が前回の値で、Enter だけならそれを使う）。
# 入れ直すたびに宛先・指紋・トークンを打たせていた（利用者の言葉:「何回も入れさせるなよ。
# どっかに保存してるんでしょ？再利用しろよ」）。保存先は fatmax setup が書く2つ:
#   %USERPROFILE%\.fatmax\hub         いまの宛先（1行）
#   %USERPROFILE%\.fatmax\known_hubs  1行に「指紋 トークン 宛先」
$prevHub = ''
$hubFile = Join-Path $HOME '.fatmax\hub'
if (Test-Path $hubFile) { $prevHub = ([string](Get-Content -Encoding UTF8 $hubFile | Select-Object -First 1)).Trim() }
$known = @()
$knownFile = Join-Path $HOME '.fatmax\known_hubs'
if (Test-Path $knownFile) {
  $known = @(Get-Content -Encoding UTF8 $knownFile | Where-Object { $_.Trim() -and -not $_.StartsWith('#') } |
    ForEach-Object { , @($_.Trim() -split '\s+') })
}
function Ask($label, $prev, $shown) {
  $q = if ($prev) { "$label [$shown]" } else { $label }
  while ($true) {
    $v = ([string](Read-Host $q)).Trim()
    if ($v) { return $v }
    if ($prev) { return $prev }
  }
}

if (-not $Hub.Trim()) { $Hub = Ask 'ハブのアドレス（例: 192.168.0.10:8787）' $prevHub $prevHub }
$Hub = $Hub.Trim().TrimEnd('/')
if ($Hub -notmatch '^https?://') { $Hub = "https://$Hub" }
# 指紋とトークンは、その宛先で覚えたものを先に探す。宛先が変わっていても（DHCP で IP が動いた）
# 覚えているハブが1つだけなら、それを前回の値として出す（指紋は IP が動いても変わらない）。
$prev = $known | Where-Object { $_.Count -ge 3 -and $_[2].TrimEnd('/') -eq $Hub } | Select-Object -Last 1
if (-not $prev -and $known.Count -eq 1) { $prev = $known[0] }
$prevPin = if ($prev) { $prev[0] } else { '' }
$prevToken = if ($prev -and $prev.Count -ge 2) { $prev[1] } else { '' }
if (-not $Pin.Trim()) {
  $Pin = Ask '指紋（ハブの画面の「導入」に出ている sha256//…）' $prevPin $prevPin
}
if (-not $Token.Trim()) {
  # トークンは画面に全部は出さない（端末の出力は人に貼られる）。末尾4文字だけ見せる
  $tail = if ($prevToken.Length -gt 4) { '…' + $prevToken.Substring($prevToken.Length - 4) } else { $prevToken }
  $Token = Ask 'トークン（同じ場所に出ています）' $prevToken $tail
}

$dir = Join-Path $HOME '.fatmax'
$bin = Join-Path $dir 'bin'
$exe = Join-Path $bin 'fatmax.exe'
New-Item -ItemType Directory -Force -Path $bin | Out-Null

# 1. 置く。**動いている .exe は上書きできない**ので、ここに置いたウォッチャーだけ先に止める。
Get-Process fatmax -ErrorAction SilentlyContinue |
  Where-Object { $_.Path -eq $exe } |
  ForEach-Object { Write-Host "動いているウォッチャーを止めます (pid $($_.Id))"; Stop-Process -Id $_.Id -Force }
Start-Sleep -Milliseconds 500
Copy-Item $src $exe -Force
# ブラウザで落とした zip から出したものには「Web から来た」印が付いたまま写る。
# 付いていると SmartScreen / Smart App Control が止めるので外しておく（無ければ何もしない）。
try { Unblock-File $exe } catch { }
Write-Host "置きました: $exe"
& $exe --version

# 2. 宛先・指紋・トークンを保存し、届くか確かめる（%USERPROFILE%\.fatmax\hub と known_hubs）。
#    **届かないまま入れると、記録が溜まるだけで誰も気付かない**ので、取れなければここで止める。
$Pin = $Pin.Trim(); $Token = $Token.Trim()
& $exe setup --hub $Hub --pin $Pin --token $Token
# **取る間だけ、出力を UTF-8 として読ませる。** PowerShell は外のコマンドの出力を
# [Console]::OutputEncoding（日本語版なら Shift_JIS）で読むので、ハブが UTF-8 で返す
# setup.ps1 の日本語が化ける（構文は壊れないが、案内の文言が全部読めなくなる）。
# 窓の設定そのものを変えるので、終わったら必ず戻す（install.cmd を叩いた PowerShell にも残る）。
$enc = [Console]::OutputEncoding
try {
  [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding $false
  $ps1 = (& $exe fetch /setup.ps1 | Out-String)
} finally {
  [Console]::OutputEncoding = $enc
}
if ($LASTEXITCODE -ne 0 -or -not $ps1.Trim()) {
  Write-Host "✗ ハブから取れません: $Hub" -ForegroundColor Red
  Write-Host '  ハブの IP・ポート・ファイアウォールと、指紋・トークンを確かめてください。やり直すなら:'
  Write-Host "    .\install.cmd -Hub https://<ハブの IP>:8787 -Pin <指紋> -Token <トークン>"
  exit 1
}
Write-Host "✓ ハブに届きます: $Hub" -ForegroundColor Green

# 3. hook と OTel。**ハブが配っている setup.ps1 をそのまま使う**（決める場所を1つにする）。
#    -Shell は指定されたときだけ渡す（0.1.169 までのハブの setup.ps1 は -Shell を知らず、渡すと止まる）。
#    -Plugin も同じ（付けたときだけ渡す）。
$sb = [scriptblock]::Create($ps1)
$extra = @{}
if ($Shell -ne 'auto') { $extra['Shell'] = $Shell }
if ($Plugin) { $extra['Plugin'] = $true }
& $sb @extra

# 5. ウォッチャー。**動かさないと記録はハブへ上がらない**（溜まるだけで消えはしない）。
#    **普通の窓で起こす。** 以前は裏で起こしていて、動いているのか・止まったのかが画面から
#    一切わからなかった（利用者の言葉:「hidden で watch が起動するから なおのことわかりにくい」）。
#    窓には版・宛先・ハブへ届くかが出る。窓を閉じれば止まる。
if (-not $NoStart) {
  Start-Process -FilePath $exe -ArgumentList 'watch'
  Start-Sleep -Seconds 3
  & $exe status
}

Write-Host ''
Write-Host '終わりました。**Claude Code を開き直してください**（OTel の設定は起動時にしか読まれません）。'
Write-Host 'ウォッチャーは別の窓で動いています（その窓を閉じると止まります）。'
Write-Host 'サインアウト・再起動でも止まります。そのときはもう一度:'
Write-Host "    Start-Process '$exe' -ArgumentList watch"
Write-Host '画面に出る名前を変えるなら:'
Write-Host "    Set-Content `"$HOME\.claude\fatmax-host`" '開発機-Win'"
